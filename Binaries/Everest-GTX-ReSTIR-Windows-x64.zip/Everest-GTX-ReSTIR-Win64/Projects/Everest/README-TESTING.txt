================================================================================
EVEREST — NATIVE VULKAN WEB-REFERENCE PARITY PREVIEW (WINDOWS x64)
================================================================================

SOURCE REVISION
  1e55d8bc3284a74fa3b45b15271f07f3e91b1758

QUICK START (Windows x64, Vulkan 1.3)
  1. Extract the complete archive; do not run an executable from inside the ZIP.
  2. Launch `Projects\Everest\Everest.exe` for the standalone proving ground.
  3. Alternatively launch `Frontier.exe` and open `Projects\Everest\Everest.projectspace`.

RENDER MODES
  Fast Preview
    GPU-only RGBA16F preview, GPU ACES/sRGB display resolve, simple preview sky,
    fast shadows, and no per-frame GPU-to-CPU-to-GPU image transfer.

  Hybrid / GTX (default)
    Hardware triangle primary visibility (`SurfaceRaster`/`ForwardRaster`) with
    hardware derivatives; deterministic cascaded-shadow direct light; half-resolution
    SDF + Surface Card ReSTIR GI; screen-first CWBVH ray-traced reflections; physical
    atmosphere, volumetric clouds, fog, and optical flare; temporal/à-trous filtering.

  Full RT
    Hardware triangle primary visibility, ray-traced analytical-light visibility,
    half-resolution CWBVH ReSTIR GI and CWBVH reflections. Analytical direct emitters
    are evaluated deterministically to avoid one-sample fireflies. Clearcoat paint uses
    stable layered reflection and band-limited flake NDF variance rather than stochastic
    per-cell normals.

CONTROLS AND LOGS
  - Hold RMB in the Scene Viewport and use WASD / Q / E; hold Shift for fast movement.
  - Press R while flying (or use Reset Cam) to restore the default viewpoint.
  - Renderer telemetry is written beside the standalone executable when enabled.

BUILD / TEST STATUS
  - Cross-compiled with pinned ziglang 0.13.0 for x86_64-windows-gnu, Release, static.
  - Both executables were verified as PE32+ AMD64 and contain revision 1e55d8bc.
  - All 29 native environment/illumination SPIR-V archives are included.
  - SwiftShader Vulkan SpatiotemporalIlluminationValidation passed on Linux, including
    Hybrid and Full-RT output generation. Native Windows startup and physical GPU/driver
    performance cannot be executed in this Linux build environment; this is an unsigned
    test build and Windows SmartScreen may warn.
================================================================================
