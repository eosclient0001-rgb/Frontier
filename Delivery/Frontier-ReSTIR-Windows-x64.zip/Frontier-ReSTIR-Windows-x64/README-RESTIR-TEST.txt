FRONTIER ReSTIR TEST PACKAGE (Windows x64, unsigned local cross-compile)
Source: eosclient0001-rgb/Frontier branch arena/a5f8b164-frontier (ReSTIR seed-bank
correlation fix + 2D spatial verification). Binaries cross-compiled with the repo-pinned
Zig 0.13 toolchain; shaders compiled from Frontier/Engine/Rendering/Shaders to SPIR-V.

1) STATISTICAL CHECKS - run anywhere, no GPU needed:
   ReplaySeedCorrelationValidation.exe
   Expect: "ReplaySeedCorrelationValidation PASS" with stationary/dynamic bias within
   +-1.3% and |z| <= 1 (temporal+bank combined was -25.6% before the fix).
   PathReplayDomainValidation.exe and PathReplayVulkanValidation.exe are host-side
   recorder/domain checks and should also exit 0.

2) REAL GPU CHECK - needs your GPU's Vulkan driver (vulkan-1.dll ships with your
   graphics driver; default path C:\Windows\System32\vulkan-1.dll):
   LightComputeValidation.exe C:\Windows\System32\vulkan-1.dll Shaders --replay-sample-history
   This runs the actual Slang ReSTIR pipeline on your GPU: subpixel seed retracing,
   temporal+spatial+bank COMBINED reservoir check (expects a line starting
   "SAMPLE_COMBINED temporal=1 spatial=1 accepted=... bank_shift_unused_draw=1"),
   facet convergence, multibounce references and history guards. Expect a final
   "PASS bounded subpixel seed retracing..." line.

3) VISUAL PROOF ON YOUR GPU (64x64, fast):
   LightComputeValidation.exe C:\Windows\System32\vulkan-1.dll Shaders --capture-replay-sample-history Captures
   Writes Captures\ReplaySampleFresh.ppm (one fresh path), ReplaySampleFourFresh.ppm
   (four fresh paths), ReplaySampleRetraced.ppm (seed-bank retracing) and
   ReplaySampleAcceptance.ppm (green=full bank, blue=partial, red=rejected/fresh-exact).

Please send back the console output of (2) - that closes the last ReSTIR verification
item (GPU combined check), which cannot run in the Linux sandbox (no Vulkan driver).
Notes: unsigned binaries (SmartScreen may warn). Source correspondence and proofs:
Exhibits/LightCompute/ReplaySeedCorrelation.md in the repo.
