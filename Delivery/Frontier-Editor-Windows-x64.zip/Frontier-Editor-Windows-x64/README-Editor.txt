Frontier Editor — windowed project build with live ReSTIR viewport
==================================================================

WHAT THIS IS
------------
FrontierEditor.exe is the full FRONTIER_WITH_INTERFACE_SDK project window:
Control Centre, Viewport, Outliner, Inspector and LogStream in one window.
The Viewport now renders a real scene with the Engine ReSTIR renderer
(Frontier/Engine/Rendering/ReplayViewportRenderer): a bounded diffuse room
(floor, ceiling, four walls, emissive ceiling panel, emissive window,
centre blocker) lit by combined temporal + spatial + seed-bank reservoir
path replay at four bounces, running on its own Vulkan compute device and
presented into the panel every frame. The camera drifts slowly so temporal
reuse is exercised live. The status line under the image reports the frame
number, accepted seed banks and submit time.

RUN
---
1. Extract the zip anywhere. Keep FrontierEditor.exe and Shaders\ together.
2. Double-click FrontierEditor.exe.
3. If a project folder is requested, pick any folder (Project-Zero works:
   its Project.toml descriptor is loaded and shown in the panels).
4. The Viewport panel renders the ReSTIR room; the LogStream shows
   "ReSTIR viewport renderer initialised (combined reservoir mode)".

REQUIREMENTS
------------
- Windows 10/11 x64 with a Vulkan 1.x driver (any discrete or integrated
  GPU with storage-buffer compute). vulkan-1.dll is loaded at runtime.
- No other files, installers or admin rights are needed (statically linked).

FIRST-RUN VISUAL CHECK
----------------------
- Ceiling panel and right window should read as the two bright emitters;
  the centre box occludes the floor beneath it; walls tinted (left green,
  right red) with soft bounce. The image converges over the first frames
  and stays temporally stable while the camera drifts.
- If the driver or shaders are missing, the panel prints the exact
  diagnostic instead of an image — tell us what it says.

VALIDATION COMPANION
--------------------
Frontier-ReSTIR-Windows-x64.zip (same repository, Delivery/) remains the
headless statistical validator: run
  LightComputeValidation.exe C:\Windows\System32\vulkan-1.dll Shaders --replay-sample-history
for the combined-mode GPU acceptance numbers.

BUILD
-----
Target: FrontierEditor (root CMakeLists.txt), sources in
Frontier/Applications/Editor/FrontierMain.cpp +
Frontier/Engine/Rendering/ReplayViewportRenderer.{h,cpp} +
Engine/Interface/VulkanPresentation dynamic textures.
SPIR-V shaders are rebuilt from Frontier/Engine/Rendering/Shaders/*.slang.
